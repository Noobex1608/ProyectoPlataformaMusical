export interface Propina {
    id: number;
    artistaId?: number;
    nombreFan?: string;
    monto?: number;
    cantidad?: number;
    mensaje: string;
    fecha: Date;
}
  