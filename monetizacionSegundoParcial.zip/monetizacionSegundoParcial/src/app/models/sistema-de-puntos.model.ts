export interface Punto {
    total?: number; // Opcional si ya no se usa directamente
    cantidad: number;
    motivo: string;
    fecha: Date;
    usuarioId: string;
}
    