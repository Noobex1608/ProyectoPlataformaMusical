export interface Recompensa {
    id: number;
    titulo: string;
    descripcion: string;
    puntosRequeridos: number; // ← nombre correcto
}
  