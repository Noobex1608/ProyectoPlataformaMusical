export interface Membresia {
    id: number;
    nombre: string;
    precio: number;
    descripcion: string;
    duracionDias: number;
    beneficios: string[];
}
  