// recompensa.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Import your RecompensaComponent here if it exists
// import { RecompensaComponent } from './recompensa.component';

@NgModule({
    declarations: [
        // RecompensaComponent
    ],
    imports: [
        CommonModule
    ],
    providers: []
})
export class RecompensaModule { }