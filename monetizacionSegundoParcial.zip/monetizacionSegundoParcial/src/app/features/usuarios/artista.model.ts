export interface Artista {
    id: number;
    nombre: string;
}
  